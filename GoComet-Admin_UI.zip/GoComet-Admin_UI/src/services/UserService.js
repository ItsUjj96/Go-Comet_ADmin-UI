import axios from "axios";
import {processUsersResponse} from "../utilities/UsersUtility";

const API_URL =
  "https://mocki.io/v1/d4867d8b-b5d5-4a48-a4ab-79131b5809b8";

const getUsers = (setUsers) => {
  axios
    .get(API_URL)
    .then((res) => {
      setUsers(processUsersResponse(res.data));
    })
    .catch((err) => getLocalUsers(setUsers));
};

const getLocalUsers = (setUsers) => {
  axios
    .get("./members.json")
    .then((res) => {
      setUsers(processUsersResponse(res.data));
    })
    .catch((error) => console.error(error));
};
export { getUsers };
